package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

const maxData = 100

type user struct {
	id       int
	name     string
	role     string
	username string
	password string
}
type userList struct {
	length int
	data   [maxData]user
}

type chat struct {
	idChat   int
	fromUser string
	chatData string
}

type forum struct {
	idForum         int
	topikKonsultasi string
	lengthChat      int
	chatData        [maxData]chat
}

type dataForum struct {
	length int
	lastID int
	data   [maxData]forum
}

var dataForums = dataForum{length: 0, data: [maxData]forum{}}
var users userList
var currentUser user

func main() {
	for {
		fmt.Println("\nSelamat datang di Konsultasi Kesehatan!")
		fmt.Println("1. Masuk sebagai Dokter")
		fmt.Println("2. Masuk sebagai Pengguna Terdaftar")
		fmt.Println("3. Masuk sebagai Pengguna Tidak Terdaftar")
		fmt.Println("0. keluar")
		fmt.Print("Pilihan Anda: ")

		var pilihan int
		fmt.Scanln(&pilihan)

		switch pilihan {
		case 1:
			menuDokter()
		case 2:
			menuPenggunaTeregistrasi()
		case 3:
			menuPenggunaTidakTeregistrasi()
		case 0:
			return
		default:
			fmt.Println("Pilihan tidak valid, coba lagi.")
		}
	}
}

func HandleLongInput(text *string) {
	reader := bufio.NewReader(os.Stdin)
	dataInput, err := reader.ReadString('\n')
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	*text = strings.TrimSpace(dataInput)

}

func registerDokter() {

	var name, username, password string
	fmt.Print("Nama: ")
	HandleLongInput(&name)
	fmt.Print("Username: ")
	fmt.Scanln(&username)
	fmt.Print("Password: ")
	fmt.Scanln(&password)

	users.data[users.length] = user{
		id:       users.length + 1,
		name:     name,
		role:     "dokter",
		username: username,
		password: password,
	}
	users.length++
	fmt.Println("berhasil registrasi!")
}
func registerUser() {

	var name, username, password string
	fmt.Print("Nama: ")
	HandleLongInput(&name)
	fmt.Print("Username: ")
	fmt.Scanln(&username)
	fmt.Print("Password: ")
	fmt.Scanln(&password)

	users.data[users.length] = user{
		id:       users.length + 1,
		name:     name,
		role:     "pasien",
		username: username,
		password: password,
	}
	users.length++
	fmt.Println("berhasil registrasi!")
}

func loginUser() bool {

	var username, password string
	fmt.Print("Username: ")
	fmt.Scanln(&username)
	fmt.Print("Password: ")
	fmt.Scanln(&password)

	for i := 0; i < users.length; i++ {
		if users.data[i].username == username && users.data[i].password == password {
			currentUser = users.data[i]
			fmt.Println("Login berhasil! Selamat datang,", currentUser.name)

			return true
		}
	}
	fmt.Println("Login gagal! Username atau password salah.")
	return false
}
func menuDokter() {
	for {
		fmt.Println("1. Registrasi")
		fmt.Println("2. Login")
		fmt.Println("0. Kembali ke menu utama")
		fmt.Print("Pilihan: ")
		var choice int
		fmt.Scanln(&choice)

		switch choice {
		case 1:
			registerDokter()
		case 2:
			if loginUser() == true {
				menuDokterLogin()
			}
		case 0:
			return
		default:
			fmt.Println("Pilihan tidak valid.")
		}
	}
}

func menuDokterLogin() {
	for {
		fmt.Println("1. Tambah Forum")
		fmt.Println("2. Lihat Forum")
		fmt.Println("3. Masuk Forum")
		fmt.Println("0. Keluar")
		fmt.Print("Pilihan: ")
		var choice int
		fmt.Scanln(&choice)

		switch choice {
		case 1:
			tambahForum()
		case 2:
			lihatForum()
		case 3:
			masukForum()
		case 0:
			return
		default:
			fmt.Println("Pilihan tidak valid.")
		}
	}
}

func menuUserLogin() {
	for {
		fmt.Println("1. Masuk Forum Untuk bertanya")
		fmt.Println("2. Lihat Forum")
		fmt.Println("3. Cari Tag Pertanyaan")
		fmt.Println("4. Tampilkan Urutan Tag")
		fmt.Println("0. Keluar")
		fmt.Print("Pilihan: ")
		var choice int
		fmt.Scanln(&choice)

		switch choice {
		case 1:
			masukForumSequen()
		case 2:
			lihatForum()
		case 3:
			cariPertanyaanByTag()
		case 4:
			lihatForumBerdasarkanTag()
		case 0:
			return
		default:
			fmt.Println("Pilihan tidak valid.")
		}
	}
}

func tambahForum() {
	if currentUser.role != "dokter" {
		fmt.Println("Fitur ini hanya tersedia untuk dokter.")
		return
	}

	var topikKonsultasi string
	fmt.Print("Topik Konsultasi: ")
	HandleLongInput(&topikKonsultasi)
	dataForums.lastID++
	dataForums.data[dataForums.length].idForum = dataForums.lastID
	dataForums.data[dataForums.length].topikKonsultasi = topikKonsultasi
	dataForums.length++
	fmt.Println("Forum dengan topik", topikKonsultasi, "berhasil ditambahkan.")
}

func sequentialSearchForumByID(target int) int {
	for i := 0; i < dataForums.length; i++ {
		if dataForums.data[i].idForum == target {
			return i
		}
	}
	return -1
}

func masukForumSequen() {
	if dataForums.length == 0 {
		fmt.Println("Belum ada forum konsultasi yang tersedia.")
		return
	}

	fmt.Println("Daftar Forum:")
	for i := 0; i < dataForums.length; i++ {
		fmt.Printf("- ID Forum: %d, Topik: %s\n", dataForums.data[i].idForum, dataForums.data[i].topikKonsultasi)
	}

	fmt.Print("Masukkan ID forum (-1 untuk kembali): ")
	var forumID int
	fmt.Scanln(&forumID)

	if forumID == -1 {
		return
	}

	index := sequentialSearchForumByID(forumID)
	if index == -1 {
		fmt.Println("Forum dengan ID tersebut tidak ditemukan.")
	}
	chatInForum(index)
}

func masukForum() {
	var arrChoice [maxData]int
	var count int
	for i := 0; i < dataForums.length; i++ {
		arrChoice[count] = i
		count++
		fmt.Println(count, " Topik: ", dataForums.data[i].topikKonsultasi)
	}
	fmt.Println("0. Kembali")
	fmt.Print("Pilihan: ")
	var choice int
	fmt.Scanln(&choice)
	if choice == 0 {
		return
	}
	chatInForum(arrChoice[choice-1])
}

func chatInForum(forumIndex int) {
	for {

		fmt.Println("Topik: ", dataForums.data[forumIndex].topikKonsultasi)
		for i := 0; i < dataForums.data[forumIndex].lengthChat; i++ {
			fmt.Println(dataForums.data[forumIndex].chatData[i].fromUser, ": ", dataForums.data[forumIndex].chatData[i].chatData)
		}
		fmt.Print("Chat (-1 untuk kembali): ")
		var chat string
		HandleLongInput(&chat)
		if chat == "-1" {
			return
		}
		dataForums.data[forumIndex].chatData[dataForums.data[forumIndex].lengthChat].fromUser = currentUser.name
		dataForums.data[forumIndex].chatData[dataForums.data[forumIndex].lengthChat].chatData = chat
		dataForums.data[forumIndex].chatData[dataForums.data[forumIndex].lengthChat].idChat = dataForums.data[forumIndex].lengthChat
		dataForums.data[forumIndex].lengthChat++
	}
}

func lihatForum() { // Titan
	if dataForums.length == 0 {
		fmt.Println("Belum ada forum konsultasi yang tersedia.")
		return
	}

	var arrChoice [maxData]int
	var count int

	for i := 0; i < dataForums.length; i++ {
		arrChoice[count] = i
		count++
		fmt.Printf("%d. Topik: %s \n", count, dataForums.data[i].topikKonsultasi)
	}

	fmt.Println("0. Kembali")
	fmt.Print("Pilihan: ")

	var choice int
	fmt.Scanln(&choice)

	if choice == 0 {
		return
	}

	if choice > 0 && choice <= count {
		forumIndex := arrChoice[choice-1]

		fmt.Println("Topik: ", dataForums.data[forumIndex].topikKonsultasi)
		if dataForums.data[forumIndex].lengthChat == 0 {
			fmt.Println("Belum ada percakapan di forum ini.")
		} else {
			for i := 0; i < dataForums.data[forumIndex].lengthChat; i++ {
				fmt.Printf("[%s]: %s\n",
					dataForums.data[forumIndex].chatData[i].fromUser,
					dataForums.data[forumIndex].chatData[i].chatData)
			}
		}

	} else {
		fmt.Println("Pilihan tidak valid.")
	}
}

func selectionSortByTag() {
	for i := 0; i < dataForums.length-1; i++ {
		minIndex := i
		for j := i + 1; j < dataForums.length; j++ {
			if dataForums.data[j].topikKonsultasi < dataForums.data[minIndex].topikKonsultasi {
				minIndex = j
			}
		}
		dataForums.data[i], dataForums.data[minIndex] = dataForums.data[minIndex], dataForums.data[i]
	}
}

// 10 9 8 7 6 5 4 3 2 1
//1 9 8 7 6 5 4 3 2 10
//1 2 8 7 5 4 3 9 10
// 1 2 3 7 6 5 4 8 9 10

func binarySearchForumByTag(target string) int {
	low, high := 0, dataForums.length-1
	for low <= high {
		mid := (low + high) / 2
		if dataForums.data[mid].topikKonsultasi == target {
			return mid
		} else if dataForums.data[mid].topikKonsultasi < target {
			low = mid + 1
		} else {
			high = mid - 1
		}
	}
	return -1
}

func cariPertanyaanByTag() {
	if dataForums.length == 0 {
		fmt.Println("Belum ada forum konsultasi yang tersedia.")
		return
	}

	fmt.Print("Masukkan tag forum yang ingin dicari: ")
	var tag string
	HandleLongInput(&tag)

	selectionSortByTag()

	index := binarySearchForumByTag(tag)
	if index == -1 {
		fmt.Println("Forum dengan tag tersebut tidak ditemukan.")
	} else {
		fmt.Println("Topik:", dataForums.data[index].topikKonsultasi)
		if dataForums.data[index].lengthChat == 0 {
			fmt.Println("Belum ada percakapan di forum ini.")
		} else {
			for i := 0; i < dataForums.data[index].lengthChat; i++ {
				fmt.Printf("[%s]: %s\n",
					dataForums.data[index].chatData[i].fromUser,
					dataForums.data[index].chatData[i].chatData)
			}
		}
	}
}

func insertionSortAscending(arr [100]forum, count int) {
	for i := 1; i < count; i++ {
		key := arr[i]
		j := i - 1
		for j >= 0 && arr[j].topikKonsultasi > key.topikKonsultasi {
			arr[j+1] = arr[j]
			j = j - 1
		}
		arr[j+1] = key
	}
}

// 5 4 3 2 1
// 4 5 3 2 1

func insertionSortDescending(arr [100]forum, count int) {
	for i := 1; i < count; i++ {
		key := arr[i]
		j := i - 1

		for j >= 0 && arr[j].topikKonsultasi < key.topikKonsultasi {
			arr[j+1] = arr[j]
			j = j - 1
		}
		arr[j+1] = key
	}
}

func lihatForumBerdasarkanTag() {
	if dataForums.length == 0 {
		fmt.Println("Belum ada forum konsultasi yang tersedia.")
		return
	}

	fmt.Println("1. Urutkan Berdasarkan Tag Ascending")
	fmt.Println("2. Urutkan Berdasarkan Tag Descending")
	fmt.Print("Pilih urutan: ")

	var choice int
	fmt.Scanln(&choice)

	var forums [100]forum
	var count int

	for i := 0; i < dataForums.length; i++ {
		forums[count] = dataForums.data[i]
		count++
	}

	if choice == 1 {
		insertionSortAscending(forums, count)
		fmt.Println("Menampilkan forum berdasarkan tag secara Ascending:")
	} else if choice == 2 {
		insertionSortDescending(forums, count)
		fmt.Println("Menampilkan forum berdasarkan tag secara Descending:")
	} else {
		fmt.Println("Pilihan tidak valid.")
		return
	}

	for i := 0; i < count; i++ {
		fmt.Printf("%d. Topik: %s \n", i+1, forums[i].topikKonsultasi)
		if forums[i].lengthChat == 0 {
			fmt.Println("   Belum ada percakapan di forum ini.")
		} else {
			for j := 0; j < forums[i].lengthChat; j++ {
				fmt.Printf("   [%s]: %s\n", forums[i].chatData[j].fromUser, forums[i].chatData[j].chatData)
			}
		}
	}
}

func menuPenggunaTeregistrasi() {
	for {
		fmt.Println("1. Registrasi")
		fmt.Println("2. Login")
		fmt.Println("0. Kembali ke Menu Utama")
		fmt.Print("Pilihan: ")
		var choice int
		fmt.Scanln(&choice)

		switch choice {
		case 1:
			registerUser()
		case 2:
			if loginUser() == true {
				menuUserLogin()
			}
		case 0:
			return
		default:
			fmt.Println("Pilihan tidak valid.")
		}
	}
}
func menuPenggunaTidakTeregistrasi() {
	for {
		var pilihan int
		fmt.Println("Manu Pengguna Tidak Terdaftar: ")
		fmt.Println("1. Lihat Forum Pertanyaan: ")
		fmt.Println("2. Kembali ke Menu Utama: ")
		fmt.Print("Pilihan: ")
		fmt.Scanln(&pilihan)
		switch pilihan {
		case 1:
			lihatForum()
		case 2:
			return
		default:
			fmt.Println("Pilihan tidak valid!")
		}
	}
}

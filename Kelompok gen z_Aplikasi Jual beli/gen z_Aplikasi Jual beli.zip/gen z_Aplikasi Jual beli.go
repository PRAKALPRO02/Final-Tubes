package main

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"runtime"
	"strconv"
	"strings"
	"time"
)

type Barang struct {
	Nama     string
	Kategori string
	Harga    float64
	Stok     int
}

type Transaksi struct {
	Barang  string
	Jumlah  int
	Tanggal time.Time
}

const maxBarang = 100
const maxTransaksi = 100

var barang [maxBarang]Barang
var transaksi [maxTransaksi]Transaksi
var countBarang int
var countTransaksi int

// clear screen
func clearScreen() {
	if runtime.GOOS == "windows" {
		cmd := exec.Command("cmd", "/c", "cls")
		cmd.Stdout = os.Stdout
		cmd.Run()
	} else {
		cmd := exec.Command("clear")
		cmd.Stdout = os.Stdout
		cmd.Run()
	}
}

// Fungsi untuk menambah barang
func tambahBarang(nama string, kategori string, harga float64, stok int) {
	if countBarang < maxBarang {
		b := Barang{
			Nama:     strings.TrimSpace(nama),
			Kategori: strings.TrimSpace(kategori),
			Harga:    harga,
			Stok:     stok,
		}
		barang[countBarang] = b
		countBarang++
	} else {
		fmt.Println("Tidak dapat menambah barang, array penuh.")
	}
}

func updateBarang(no int, nama string, kategori string, harga float64, stok int) {
	if no < 1 || no > countBarang {
		fmt.Println("Barang dengan nomor tersebut tidak ditemukan.")
		return
	}
	barang[no-1] = Barang{
		Nama:     strings.TrimSpace(nama),
		Kategori: strings.TrimSpace(kategori),
		Harga:    harga,
		Stok:     stok,
	}
}

func hapusBarang(no int) {
	if no < 1 || no > countBarang {
		fmt.Println("Barang dengan nomor tersebut tidak ditemukan.")
		return
	}
	for i := no - 1; i < countBarang-1; i++ {
		barang[i] = barang[i+1]
	}
	countBarang--
	fmt.Println("Barang berhasil dihapus.")
}

func tambahTransaksi(namaBarang string, jumlah int, tanggal time.Time) (bool, string) {
	var validBarang bool
	var stokBarang int
	for i := 0; i < countBarang; i++ {
		if barang[i].Nama == namaBarang {
			validBarang = true
			stokBarang = barang[i].Stok
		}
	}

	if !validBarang {
		return false, "Nama barang tidak ditemukan."
	}

	if stokBarang < jumlah {
		return false, "Stok tidak mencukupi."
	}

	for i := 0; i < countBarang; i++ {
		if barang[i].Nama == namaBarang {
			barang[i].Stok -= jumlah
		}
	}

	transaksi[countTransaksi] = Transaksi{namaBarang, jumlah, tanggal}
	countTransaksi++
	return true, "Transaksi berhasil ditambah."
}

func updateTransaksi(no int, namaBarang string, jumlah int, tanggal time.Time) (bool, string) {
	if no < 1 || no > countTransaksi {
		return false, "Transaksi dengan nomor tersebut tidak ditemukan."
	}

	idx := no - 1

	for j := 0; j < countBarang; j++ {
		if barang[j].Nama == transaksi[idx].Barang {
			barang[j].Stok += transaksi[idx].Jumlah

			j = countBarang // Memastikan loop berhenti
		}
	}

	// Validasi stok baru setelah mengembalikan stok lama
	stokCukup := false
	for j := 0; j < countBarang; j++ {
		if barang[j].Nama == namaBarang {
			if barang[j].Stok >= jumlah {
				// Kurangi stok barang baru
				barang[j].Stok -= jumlah
				stokCukup = true
			}
			j = countBarang
		}
	}

	if stokCukup {
		transaksi[idx] = Transaksi{namaBarang, jumlah, tanggal}
		return true, "Transaksi berhasil diperbarui."
	}
	return false, "Stok tidak mencukupi atau barang tidak ditemukan."
}

func hapusTransaksi(no int) bool {
	if no < 1 || no > countTransaksi {
		return false
	}

	idx := no - 1

	// Kembalikan stok barang
	for j := 0; j < countBarang; j++ {
		if barang[j].Nama == transaksi[idx].Barang {
			barang[j].Stok += transaksi[idx].Jumlah
			j = countBarang
		}
	}

	// Hapus transaksi
	for k := idx; k < countTransaksi-1; k++ {
		transaksi[k] = transaksi[k+1]
	}
	countTransaksi--
	return true
}

func lihatDetailTransaksi(namaBarang string) {
	var transaksiDetails []Transaksi
	for i := 0; i < countTransaksi; i++ {
		if transaksi[i].Barang == namaBarang {
			transaksiDetails = append(transaksiDetails, transaksi[i])
		}
	}

	if len(transaksiDetails) == 0 {
		fmt.Println("Transaksi dengan nama barang tersebut tidak ditemukan.")
		return
	}

	maxNoLength := len(fmt.Sprintf("%d", len(transaksiDetails)))
	maxBarangLength := len("Barang")
	maxJumlahLength := len("Jumlah")
	maxTanggalLength := len("Tanggal")
	maxTotalPenjualanLength := len("Total Penjualan")

	for _, t := range transaksiDetails {
		if len(t.Barang) > maxBarangLength {
			maxBarangLength = len(t.Barang)
		}
		if len(fmt.Sprintf("%d", t.Jumlah)) > maxJumlahLength {
			maxJumlahLength = len(fmt.Sprintf("%d", t.Jumlah))
		}
		if len(t.Tanggal.Format("2006-01-02")) > maxTanggalLength {
			maxTanggalLength = len(t.Tanggal.Format("2006-01-02"))
		}
		if len(fmt.Sprintf("Rp. %.2f", float64(t.Jumlah)*getHargaBarang(t.Barang))) > maxTotalPenjualanLength {
			maxTotalPenjualanLength = len(fmt.Sprintf("Rp. %.2f", float64(t.Jumlah)*getHargaBarang(t.Barang)))
		}
	}

	fmt.Printf("+-%s-+-%s-+-%s-+-%s-+-%s-+\n", strings.Repeat("-", maxNoLength+2), strings.Repeat("-", maxBarangLength+1), strings.Repeat("-", maxJumlahLength), strings.Repeat("-", maxTanggalLength), strings.Repeat("-", maxTotalPenjualanLength))
	fmt.Printf("| %-*s | %-*s | %-*s | %-*s | %-*s |\n", maxNoLength+2, "No", maxBarangLength+1, "Barang", maxJumlahLength, "Jumlah", maxTanggalLength, "Tanggal", maxTotalPenjualanLength, "Total Penjualan")
	fmt.Printf("+-%s-+-%s-+-%s-+-%s-+-%s-+\n", strings.Repeat("-", maxNoLength+2), strings.Repeat("-", maxBarangLength+1), strings.Repeat("-", maxJumlahLength), strings.Repeat("-", maxTanggalLength), strings.Repeat("-", maxTotalPenjualanLength))

	for i, t := range transaksiDetails {
		fmt.Printf("| %-*d | %-*s | %-*d | %-*s | %-*s |\n", maxNoLength+2, i+1, maxBarangLength+1, t.Barang, maxJumlahLength, t.Jumlah, maxTanggalLength, t.Tanggal.Format("2006-01-02"), maxTotalPenjualanLength, fmt.Sprintf("Rp. %.2f", float64(t.Jumlah)*getHargaBarang(t.Barang)))
	}
	fmt.Printf("+-%s-+-%s-+-%s-+-%s-+-%s-+\n", strings.Repeat("-", maxNoLength+2), strings.Repeat("-", maxBarangLength+1), strings.Repeat("-", maxJumlahLength), strings.Repeat("-", maxTanggalLength), strings.Repeat("-", maxTotalPenjualanLength))
}

// Fungsi untuk menghitung lebar kolom maksimum
func maxLength(header string, values []string) int {
	max := len(header)
	for _, v := range values {
		if len(v) > max {
			max = len(v)
		}
	}
	return max
}

func sequentialSearch(keyword string) bool {
	found := false
	for i := 0; i < countBarang; i++ {
		if strings.Contains(strings.ToLower(barang[i].Nama), strings.ToLower(keyword)) ||
			strings.Contains(strings.ToLower(barang[i].Kategori), strings.ToLower(keyword)) ||
			strings.Contains(strings.ToLower(fmt.Sprintf("%d", barang[i].Stok)), strings.ToLower(keyword)) {
			displaySingleBarang(i)
			found = true
		}
	}
	return found
}

func binarySearch(nama string) int {
	low, high := 0, countBarang-1
	for low <= high {
		mid := (low + high) / 2
		if barang[mid].Nama < nama {
			low = mid + 1
		} else if barang[mid].Nama > nama {
			high = mid - 1
		} else {
			return mid
		}
	}
	return -1 // Tidak ditemukan
}

// Fungsi untuk menampilkan barang berdasarkan index dengan format tabel
func displaySingleBarang(index int) {
	b := barang[index]

	namaLengths := []string{b.Nama}
	kategoriLengths := []string{b.Kategori}
	hargaLengths := []string{fmt.Sprintf("Rp. %.2f", b.Harga)}
	stokLengths := []string{fmt.Sprintf("%d", b.Stok)}

	maxNama := maxLength("Nama", namaLengths)
	maxKategori := maxLength("Kategori", kategoriLengths)
	maxHarga := maxLength("Harga", hargaLengths)
	maxStok := maxLength("Stok", stokLengths)

	fmt.Printf("+%s+%s+%s+%s+%s+\n", strings.Repeat("-", 6), strings.Repeat("-", maxNama+2), strings.Repeat("-", maxKategori+2), strings.Repeat("-", maxHarga+2), strings.Repeat("-", maxStok+2))
	fmt.Printf("| %-4s | %-*s | %-*s | %-*s | %-*s |\n", "No.", maxNama, "Nama", maxKategori, "Kategori", maxHarga, "Harga", maxStok, "Stok")
	fmt.Printf("+%s+%s+%s+%s+%s+\n", strings.Repeat("-", 6), strings.Repeat("-", maxNama+2), strings.Repeat("-", maxKategori+2), strings.Repeat("-", maxHarga+2), strings.Repeat("-", maxStok+2))
	fmt.Printf("| %-4d | %-*s | %-*s | %-*s | %-*d |\n", index+1, maxNama, b.Nama, maxKategori, b.Kategori, maxHarga, fmt.Sprintf("Rp. %.2f", b.Harga), maxStok, b.Stok)
	fmt.Printf("+%s+%s+%s+%s+%s+\n", strings.Repeat("-", 6), strings.Repeat("-", maxNama+2), strings.Repeat("-", maxKategori+2), strings.Repeat("-", maxHarga+2), strings.Repeat("-", maxStok+2))
}

// Fungsi untuk menyimpan data barang ke file
func simpanBarangKeFile(filename string) {
	file, err := os.Create(filename)
	if err != nil {
		fmt.Println("Error creating file:", err)
		return
	}
	defer file.Close()

	writer := bufio.NewWriter(file)
	for i := 0; i < countBarang; i++ {
		line := fmt.Sprintf("%s,%s,%.2f,%d\n", barang[i].Nama, barang[i].Kategori, barang[i].Harga, barang[i].Stok)
		writer.WriteString(line)
	}
	writer.Flush()
}

// Fungsi untuk membaca data barang dari file
func bacaBarangDariFile(filename string) {
	file, err := os.Open(filename)
	if err != nil {
		if os.IsNotExist(err) {

			newFile, createErr := os.Create(filename)
			if createErr != nil {
				fmt.Println("Error creating file:", createErr)
				return
			}
			newFile.Close()
			fmt.Println("File created:", filename)
			return
		} else {
			fmt.Println("Error opening file:", err)
			return
		}
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	countBarang = 0
	for scanner.Scan() {
		line := scanner.Text()
		parts := strings.Split(line, ",")
		if len(parts) == 4 {
			harga, _ := strconv.ParseFloat(parts[2], 64)
			stok, _ := strconv.Atoi(parts[3])
			barang[countBarang] = Barang{Nama: parts[0], Kategori: parts[1], Harga: harga, Stok: stok}
			countBarang++
		}
	}
}

// Fungsi untuk menyimpan data transaksi ke file
func simpanTransaksiKeFile(filename string) {
	file, err := os.Create(filename)
	if err != nil {
		fmt.Println("Error creating file:", err)
		return
	}
	defer file.Close()

	writer := bufio.NewWriter(file)
	for i := 0; i < countTransaksi; i++ {
		line := fmt.Sprintf("%s,%d,%s\n", transaksi[i].Barang, transaksi[i].Jumlah, transaksi[i].Tanggal.Format("2006-01-02"))
		writer.WriteString(line)
	}
	writer.Flush()
}

// Fungsi untuk membaca data transaksi dari file
func bacaTransaksiDariFile(filename string) {
	file, err := os.Open(filename)
	if err != nil {
		if os.IsNotExist(err) {

			newFile, createErr := os.Create(filename)
			if createErr != nil {
				fmt.Println("Error creating file:", createErr)
				return
			}
			newFile.Close()
			fmt.Println("File created:", filename)
			return
		} else {
			fmt.Println("Error opening file:", err)
			return
		}
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	countTransaksi = 0
	for scanner.Scan() {
		line := scanner.Text()
		parts := strings.Split(line, ",")
		if len(parts) == 3 {
			jumlah, _ := strconv.Atoi(parts[1])
			tanggal, _ := time.Parse("2006-01-02", parts[2])
			transaksi[countTransaksi] = Transaksi{Barang: parts[0], Jumlah: jumlah, Tanggal: tanggal}
			countTransaksi++
		}
	}
}

func tampilkanModalDanPendapatan() {
	totalModal, totalPendapatan := hitungModalDanPendapatan()

	totalModalStr := fmt.Sprintf("Rp. %.2f", totalModal)
	totalPendapatanStr := fmt.Sprintf("Rp. %.2f", totalPendapatan)

	maxNoLength := len("No")
	maxTotalModalLength := len(totalModalStr)
	maxTotalPendapatanLength := len(totalPendapatanStr)

	fmt.Printf("+-%s-+-%s-+-%s-+\n", strings.Repeat("-", maxNoLength), strings.Repeat("-", maxTotalModalLength), strings.Repeat("-", maxTotalPendapatanLength))
	fmt.Printf("| %-*s | %-*s | %-*s |\n", maxNoLength, "No", maxTotalModalLength, "Total Modal", maxTotalPendapatanLength, "Total Pendapatan")
	fmt.Printf("+-%s-+-%s-+-%s-+\n", strings.Repeat("-", maxNoLength), strings.Repeat("-", maxTotalModalLength), strings.Repeat("-", maxTotalPendapatanLength))

	fmt.Printf("| %-*d | %-*s | %-*s |\n", maxNoLength, 1, maxTotalModalLength, totalModalStr, maxTotalPendapatanLength, totalPendapatanStr)
	fmt.Printf("+-%s-+-%s-+-%s-+\n", strings.Repeat("-", maxNoLength), strings.Repeat("-", maxTotalModalLength), strings.Repeat("-", maxTotalPendapatanLength))
}

func hitungModalDanPendapatan() (float64, float64) {
	totalModal := 0.0
	totalPendapatan := 0.0

	for i := 0; i < countTransaksi; i++ {
		t := transaksi[i]
		hargaPerUnit := getHargaBarang(t.Barang)
		modalPerUnit := hargaPerUnit * 0.6
		totalModal += float64(t.Jumlah) * modalPerUnit
		totalPendapatan += float64(t.Jumlah) * hargaPerUnit
	}

	return totalModal, totalPendapatan
}

// Fungsi untuk menampilkan barang dengan pengurutan menggunakan Selection Sort atau Insertion Sort
func tampilkanBarang(kriteria string, order string, algoritma string) {
	compare := func(a, b Barang) bool {
		if order == "asc" {
			switch kriteria {
			case "Nama":
				return a.Nama < b.Nama
			case "Kategori":
				return a.Kategori < b.Kategori
			case "Harga":
				return a.Harga < b.Harga
			case "Stok":
				return a.Stok < b.Stok
			}
		} else if order == "desc" {
			switch kriteria {
			case "Nama":
				return a.Nama > b.Nama
			case "Kategori":
				return a.Kategori > b.Kategori
			case "Harga":
				return a.Harga > b.Harga
			case "Stok":
				return a.Stok > b.Stok
			}
		}
		return false
	}

	// Selection Sort
	if algoritma == "selection" {
		for i := 0; i < countBarang-1; i++ {
			minMaxIndex := i
			for j := i + 1; j < countBarang; j++ {
				if compare(barang[j], barang[minMaxIndex]) {
					minMaxIndex = j
				}
			}
			barang[i], barang[minMaxIndex] = barang[minMaxIndex], barang[i]
		}
	} else if algoritma == "insertion" {
		for i := 1; i < countBarang; i++ {
			key := barang[i]
			j := i - 1
			for j >= 0 && compare(key, barang[j]) {
				barang[j+1] = barang[j]
				j--
			}
			barang[j+1] = key
		}
	}

	// Menampilkan barang yang sudah diurutkan
	namaLengths := make([]string, countBarang)
	kategoriLengths := make([]string, countBarang)
	hargaLengths := make([]string, countBarang)
	stokLengths := make([]string, countBarang)
	for i := 0; i < countBarang; i++ {
		namaLengths[i] = barang[i].Nama
		kategoriLengths[i] = barang[i].Kategori
		hargaLengths[i] = fmt.Sprintf("Rp. %.2f", barang[i].Harga)
		stokLengths[i] = fmt.Sprintf("%d", barang[i].Stok)
	}

	maxNama := maxLength("Nama", namaLengths)
	maxKategori := maxLength("Kategori", kategoriLengths)
	maxHarga := maxLength("Harga", hargaLengths)
	maxStok := maxLength("Stok", stokLengths)

	fmt.Printf("+%s+%s+%s+%s+%s+\n", strings.Repeat("-", 6), strings.Repeat("-", maxNama+2), strings.Repeat("-", maxKategori+2), strings.Repeat("-", maxHarga+2), strings.Repeat("-", maxStok+2))
	fmt.Printf("| %-4s | %-*s | %-*s | %-*s | %-*s |\n", "No.", maxNama, "Nama", maxKategori, "Kategori", maxHarga, "Harga", maxStok, "Stok")
	fmt.Printf("+%s+%s+%s+%s+%s+\n", strings.Repeat("-", 6), strings.Repeat("-", maxNama+2), strings.Repeat("-", maxKategori+2), strings.Repeat("-", maxHarga+2), strings.Repeat("-", maxStok+2))

	for i := 0; i < countBarang; i++ {
		b := barang[i]
		fmt.Printf("| %-4d | %-*s | %-*s | %-*s | %-*d |\n", i+1, maxNama, b.Nama, maxKategori, b.Kategori, maxHarga, fmt.Sprintf("Rp. %.2f", b.Harga), maxStok, b.Stok)
	}
	fmt.Printf("+%s+%s+%s+%s+%s+\n", strings.Repeat("-", 6), strings.Repeat("-", maxNama+2), strings.Repeat("-", maxKategori+2), strings.Repeat("-", maxHarga+2), strings.Repeat("-", maxStok+2))
}

// Fungsi untuk menampilkan transaksi
func tampilkanTransaksi() {
	barangLengths := make([]string, countTransaksi)
	tanggalLengths := make([]string, countTransaksi)
	totalPenjualanLengths := make([]string, countTransaksi)

	totalJumlahTransaksi := 0
	totalPendapatan := 0.0

	for i := 0; i < countTransaksi; i++ {
		t := transaksi[i]
		barangLengths[i] = t.Barang
		tanggalLengths[i] = t.Tanggal.Format("2006-01-02")
		totalPenjualanLengths[i] = fmt.Sprintf("Rp. %.2f", float64(t.Jumlah)*getHargaBarang(t.Barang))

		// Hitung total barang terjual dan nilai total dalam uang
		totalJumlahTransaksi += t.Jumlah
		totalPendapatan += float64(t.Jumlah) * getHargaBarang(t.Barang)
	}

	maxBarang := maxLength("Barang", barangLengths)
	maxJumlah := maxLength("Jumlah", []string{"Jumlah"})
	maxTanggal := maxLength("Tanggal", tanggalLengths)
	maxTotalPenjualan := maxLength("Total Penjualan", totalPenjualanLengths)

	firstColumnWidth := max(4, len("Total"))
	maxBarang = max(maxBarang, len("Barang"))
	maxJumlah = max(maxJumlah, len("Jumlah"))
	maxTanggal = max(maxTanggal, len("Tanggal"))
	maxTotalPenjualan = max(maxTotalPenjualan, len("Total Penjualan"))

	fmt.Printf("+%s+%s+%s+%s+%s+\n", strings.Repeat("-", firstColumnWidth+2), strings.Repeat("-", maxBarang+2), strings.Repeat("-", maxJumlah+2), strings.Repeat("-", maxTanggal+2), strings.Repeat("-", maxTotalPenjualan+2))
	fmt.Printf("| %-*s | %-*s | %-*s | %-*s | %-*s |\n", firstColumnWidth, "No.", maxBarang, "Barang", maxJumlah, "Jumlah", maxTanggal, "Tanggal", maxTotalPenjualan, "Total Penjualan")
	fmt.Printf("+%s+%s+%s+%s+%s+\n", strings.Repeat("-", firstColumnWidth+2), strings.Repeat("-", maxBarang+2), strings.Repeat("-", maxJumlah+2), strings.Repeat("-", maxTanggal+2), strings.Repeat("-", maxTotalPenjualan+2))

	for i := 0; i < countTransaksi; i++ {
		t := transaksi[i]
		fmt.Printf("| %-*d | %-*s | %-*d | %-*s | %-*s |\n", firstColumnWidth, i+1, maxBarang, t.Barang, maxJumlah, t.Jumlah, maxTanggal, t.Tanggal.Format("2006-01-02"), maxTotalPenjualan, fmt.Sprintf("Rp. %.2f", float64(t.Jumlah)*getHargaBarang(t.Barang)))
	}

	// Tambahkan total transaksi dan total pendapatan di baris paling bawah
	fmt.Printf("+%s+%s+%s+%s+%s+\n", strings.Repeat("-", firstColumnWidth+2), strings.Repeat("-", maxBarang+2), strings.Repeat("-", maxJumlah+2), strings.Repeat("-", maxTanggal+2), strings.Repeat("-", maxTotalPenjualan+2))
	fmt.Printf("| %-*s | %-*s | %-*d | %-*s | %-*s |\n", firstColumnWidth, "Total", maxBarang, "", maxJumlah, totalJumlahTransaksi, maxTanggal, "", maxTotalPenjualan, fmt.Sprintf("Rp. %.2f", totalPendapatan))
	fmt.Printf("+%s+%s+%s+%s+%s+\n", strings.Repeat("-", firstColumnWidth+2), strings.Repeat("-", maxBarang+2), strings.Repeat("-", maxJumlah+2), strings.Repeat("-", maxTanggal+2), strings.Repeat("-", maxTotalPenjualan+2))
}

// function untuk mendapatkan harga barang berdasarkan nama
func getHargaBarang(namaBarang string) float64 {
	for i := 0; i < countBarang; i++ {
		if barang[i].Nama == namaBarang {
			return barang[i].Harga
		}
	}
	return 0.0 // Return 0.0 if the item is not found
}

// Function untuk menmpilkan 5 barang paling banyak terjual
func hitungPenjualanPerBarang() [maxBarang]int {
	var penjualan [maxBarang]int
	for i := 0; i < countTransaksi; i++ {
		t := transaksi[i]
		for j := 0; j < countBarang; j++ {
			if barang[j].Nama == t.Barang {
				penjualan[j] += t.Jumlah
			}
		}
	}
	return penjualan
}

func tampilkan5BarangTerbanyakTerjual() {
	penjualan := hitungPenjualanPerBarang()

	type itemPenjualan struct {
		Barang string
		Jumlah int
	}

	var items [maxBarang]itemPenjualan
	itemCount := 0

	for i := 0; i < countBarang; i++ {
		if penjualan[i] > 0 {
			items[itemCount] = itemPenjualan{Barang: barang[i].Nama, Jumlah: penjualan[i]}
			itemCount++
		}
	}

	for i := 0; i < itemCount-1; i++ {
		for j := i + 1; j < itemCount; j++ {
			if items[i].Jumlah < items[j].Jumlah {
				items[i], items[j] = items[j], items[i]
			}
		}
	}

	// menampilkan 5 barang
	fmt.Printf("+----+----------------+--------+\n")
	fmt.Printf("| No |     Barang     | Jumlah |\n")
	fmt.Printf("+----+----------------+--------+\n")
	for i := 0; i < 5 && i < itemCount; i++ {
		fmt.Printf("| %-2d | %-14s | %-6d |\n", i+1, items[i].Barang, items[i].Jumlah)
	}
	fmt.Printf("+----+----------------+--------+\n")
}

func main() {
	reader := bufio.NewReader(os.Stdin)
	barangsFile := "barang.txt"
	transaksisFile := "transaksi.txt"

	// Load data dari files
	bacaBarangDariFile(barangsFile)
	bacaTransaksiDariFile(transaksisFile)

	for {
		clearScreen()
		fmt.Println("\n=================================================")
		fmt.Println("|                   Menu                        |")
		fmt.Println("=================================================")
		fmt.Println("| 1. |Data Barang                               |")
		fmt.Println("| 2. |Data Transaksi                            |")
		fmt.Println("| 3. |Tampilkan Barang                          |")
		fmt.Println("| 4. |Tampilkan Transaksi                       |")
		fmt.Println("| 5. |Cari Barang                               |")
		fmt.Println("| 6. |Tampilkan Modal Pendapatan dari Transaksi |")
		fmt.Println("| 7. |5 Data barang yang paling banyak terjual  |")
		fmt.Println("| 8. |Simpan dan Keluar                         |")
		fmt.Println("=================================================")
		fmt.Print("Pilih menu: ")
		choiceStr, _ := reader.ReadString('\n')
		choiceStr = strings.TrimSpace(choiceStr)
		choice, err := strconv.Atoi(choiceStr)
		if err != nil {
			fmt.Println("Opsi tidak valid. Coba lagi.")
		} else {

			switch choice {
			case 1:
				clearScreen() // Membersihkan layar sebelum menampilkan submenu Data Barang
				fmt.Println("\n=======================")
				fmt.Println("|      Data Barang    |")
				fmt.Println("=======================")
				fmt.Println("| 1. Tambah Barang    |")
				fmt.Println("| 2. Update Barang    |")
				fmt.Println("| 3. Hapus Barang     |")
				fmt.Println("=======================")
				fmt.Print("Pilih menu: ")
				subChoiceStr, _ := reader.ReadString('\n')
				subChoiceStr = strings.TrimSpace(subChoiceStr)
				subChoice, err := strconv.Atoi(subChoiceStr)
				if err != nil {
					fmt.Println("Opsi tidak valid. Coba lagi.")
				} else {
					switch subChoice {
					case 1:
						var nama, kategori string
						var harga float64
						var stok int
						fmt.Print("Masukkan nama barang: ")
						nama, _ = reader.ReadString('\n')
						nama = strings.TrimSpace(nama)
						namaLower := strings.ToLower(nama)
						// Validasi nama barang
						var validBarang bool
						for i := 0; i < countBarang; i++ {
							if strings.ToLower(barang[i].Nama) == namaLower {
								validBarang = true
							}
						}
						if validBarang {
							fmt.Println("Nama barang sudah ditemukan.")
						} else {
							fmt.Print("Masukkan kategori: ")
							kategori, _ = reader.ReadString('\n')
							kategori = strings.TrimSpace(kategori)
							fmt.Print("Masukkan harga: ")
							fmt.Scan(&harga)
							reader.ReadString('\n')
							fmt.Print("Masukkan stok: ")
							fmt.Scan(&stok)
							reader.ReadString('\n')
							tambahBarang(nama, kategori, harga, stok)
							fmt.Println("Barang berhasil ditambahkan.")
						}

					case 2:
						var no int
						var nama, kategori string
						var harga float64
						var stok int
						fmt.Print("Masukkan nomor barang yang diupdate: ")
						fmt.Scan(&no)
						reader.ReadString('\n')
						if no < 1 || no > countBarang {
							fmt.Println("Barang dengan nomor tersebut tidak ditemukan.")
						} else {
							fmt.Print("Masukkan nama baru: ")
							nama, _ = reader.ReadString('\n')
							nama = strings.TrimSpace(nama)
							namaLower := strings.ToLower(nama)
							// Validasi nama barang
							var validBarang bool
							for i := 0; i < countBarang; i++ {
								if strings.ToLower(barang[i].Nama) == namaLower {
									validBarang = true
								}
							}
							if validBarang {
								fmt.Println("Nama barang sudah ditemukan.")
							} else {
								fmt.Print("Masukkan kategori baru: ")
								kategori, _ = reader.ReadString('\n')
								kategori = strings.TrimSpace(kategori)
								fmt.Print("Masukkan harga: ")
								fmt.Scan(&harga)
								reader.ReadString('\n')
								fmt.Print("Masukkan stok: ")
								fmt.Scan(&stok)
								reader.ReadString('\n')
								updateBarang(no, nama, kategori, harga, stok)
								fmt.Println("Barang berhasil diupdate.")
							}
						}

					case 3:
						var no int
						fmt.Print("Masukkan nomor barang yang dihapus: ")
						fmt.Scan(&no)
						reader.ReadString('\n')
						hapusBarang(no)
						fmt.Println("Barang berhasil dihapus.")

					default:
						fmt.Println("Pilihan tidak valid.")
					}
				}

			case 2:
				clearScreen()
				fmt.Println("\n=============================")
				fmt.Println("|       Data Transaksi      |")
				fmt.Println("=============================")
				fmt.Println("| 1. Tambah Transaksi       |")
				fmt.Println("| 2. Update Transaksi       |")
				fmt.Println("| 3. Hapus Transaksi        |")
				fmt.Println("| 4. Lihat Detail Transaksi |")
				fmt.Println("=============================")
				fmt.Print("Pilih menu: ")
				subChoiceStr, _ := reader.ReadString('\n')
				subChoiceStr = strings.TrimSpace(subChoiceStr)
				subChoice, err := strconv.Atoi(subChoiceStr)
				if err != nil {
					fmt.Println("Opsi tidak valid. Coba lagi.")
				} else {
					switch subChoice {
					case 1:
						var namaBarang string
						var jumlah int
						var tanggalStr string
						fmt.Print("Masukkan nama barang: ")
						namaBarang, _ = reader.ReadString('\n')
						namaBarang = strings.TrimSpace(namaBarang)

						// Validasi nama barang
						var validBarang bool
						for i := 0; i < countBarang; i++ {
							if barang[i].Nama == namaBarang {
								validBarang = true
							}
						}
						if !validBarang {
							fmt.Println("Nama barang tidak ditemukan.")
						} else {
							fmt.Print("Masukkan jumlah: ")
							fmt.Scan(&jumlah)
							reader.ReadString('\n')

							var stokBarang int
							for i := 0; i < countBarang; i++ {
								if barang[i].Nama == namaBarang {
									stokBarang = barang[i].Stok
								}
							}
							if stokBarang < jumlah {
								fmt.Printf("Stok tidak mencukupi: dibutuhkan %d unit, tersedia %d unit\n", jumlah, stokBarang)
							} else {
								fmt.Print("Masukkan tanggal (YYYY-MM-DD): ")
								tanggalStr, _ = reader.ReadString('\n')
								tanggalStr = strings.TrimSpace(tanggalStr)
								tanggal, _ := time.Parse("2006-01-02", tanggalStr)

								// Panggil fungsi tambahTransaksi
								if success, msg := tambahTransaksi(namaBarang, jumlah, tanggal); success {
									fmt.Println(msg)
								} else {
									fmt.Println(msg)
								}
							}
						}
					case 2:
						var no int
						var jumlah int
						var tanggalStr string

						fmt.Print("Masukkan nomor transaksi: ")
						fmt.Scan(&no)
						reader.ReadString('\n')

						if no < 1 || no > countTransaksi {
							fmt.Println("Nomor transaksi tidak ditemukan.")
							no = countTransaksi // Menghentikan iterasi
						} else {
							transaksiLama := transaksi[no-1]
							fmt.Print("Masukkan jumlah baru: ")
							fmt.Scan(&jumlah)
							reader.ReadString('\n')
							var stokBarang int
							for i := 0; i < countBarang; i++ {
								if barang[i].Nama == transaksiLama.Barang {
									stokBarang = barang[i].Stok
								}
							}
							stokLama := transaksiLama.Jumlah
							stokBaru := stokBarang + stokLama - jumlah
							if stokBaru < 0 {
								fmt.Printf("Stok tidak mencukupi: dibutuhkan %d unit, tersedia %d unit\n", jumlah, stokBarang+stokLama)
							} else {
								fmt.Print("Masukkan tanggal baru (YYYY-MM-DD): ")
								tanggalStr, _ = reader.ReadString('\n')
								tanggalStr = strings.TrimSpace(tanggalStr)
								tanggal, _ := time.Parse("2006-01-02", tanggalStr)
								if success, msg := updateTransaksi(no, transaksiLama.Barang, jumlah, tanggal); success {
									fmt.Println("Transaksi berhasil diperbarui.")
								} else {
									fmt.Println(msg)
								}
							}
						}

					case 3:
						clearScreen()
						var no int
						fmt.Print("Masukkan nomor transaksi yang dihapus: ")
						fmt.Scan(&no)
						reader.ReadString('\n')

						if hapusTransaksi(no) {
							fmt.Println("Transaksi berhasil dihapus.")
						} else {
							fmt.Println("Transaksi dengan nomor tersebut tidak ditemukan.")
						}
					case 4:
						clearScreen()
						var namaBarang string
						fmt.Print("Masukkan nama barang yang ingin dilihat: ")
						namaBarang, _ = reader.ReadString('\n')
						namaBarang = strings.TrimSpace(namaBarang)
						lihatDetailTransaksi(namaBarang)

					default:
						fmt.Println("Pilihan tidak valid.")
					}
				}

			case 3:
				clearScreen()
				fmt.Println("\n=============================")
				fmt.Println("| Pilih kriteria pengurutan |")
				fmt.Println("=============================")
				fmt.Println("| 1. Nama                   |")
				fmt.Println("| 2. Kategori               |")
				fmt.Println("| 3. Harga                  |")
				fmt.Println("| 4. Stok                   |")
				fmt.Println("=============================")
				fmt.Print("Masukkan pilihan (angka): ")
				sortChoiceStr, _ := reader.ReadString('\n')
				sortChoiceStr = strings.TrimSpace(sortChoiceStr)
				sortChoice, err := strconv.Atoi(sortChoiceStr)
				if err != nil || sortChoice < 1 || sortChoice > 4 {
					fmt.Println("Pilihan tidak valid.")
				} else {

					var kriteria string
					switch sortChoice {
					case 1:
						kriteria = "Nama"
					case 2:
						kriteria = "Kategori"
					case 3:
						kriteria = "Harga"
					case 4:
						kriteria = "Stok"
					}
					fmt.Println("\n=============================")
					fmt.Println("| Pilih algoritma pengurutan|")
					fmt.Println("=============================")
					fmt.Println("| 1. Selection Sort         |")
					fmt.Println("| 2. Insertion Sort         |")
					fmt.Println("=============================")
					fmt.Print("Masukkan pilihan (angka): ")
					algoChoiceStr, _ := reader.ReadString('\n')
					algoChoiceStr = strings.TrimSpace(algoChoiceStr)
					algoChoice, err := strconv.Atoi(algoChoiceStr)
					var algoritma string
					if err != nil || algoChoice < 1 || algoChoice > 2 {
						fmt.Println("Pilihan tidak valid. Silahkan pilih kembali.")
						algoritma = "selection"
					} else {
						if algoChoice == 1 {
							algoritma = "selection"
						} else {
							algoritma = "insertion"
						}
					}
					fmt.Println("\n=============================")
					fmt.Println("| Pilih urutan pengurutan   |")
					fmt.Println("=============================")
					fmt.Println("| 1. Ascending              |")
					fmt.Println("| 2. Descending             |")
					fmt.Println("=============================")
					fmt.Print("Masukkan pilihan (angka): ")
					orderChoiceStr, _ := reader.ReadString('\n')
					orderChoiceStr = strings.TrimSpace(orderChoiceStr)
					orderChoice, err := strconv.Atoi(orderChoiceStr)
					var order string
					if err != nil || orderChoice < 1 || orderChoice > 2 {
						fmt.Println("Pilihan tidak valid. Silahkan pilih kembali.")
						order = "asc"
					} else {
						if orderChoice == 1 {
							order = "asc"
						} else {
							order = "desc"
						}
					}
					tampilkanBarang(kriteria, order, algoritma)
					fmt.Println("Data barang telah diurutkan dan ditampilkan.")
				}
			case 4:
				clearScreen()
				tampilkanTransaksi()

			case 5:
				clearScreen()
				fmt.Println("\n=============================")
				fmt.Println("| Pilih metode pencarian    |")
				fmt.Println("=============================")
				fmt.Println("| 1. Sequential Search      |")
				fmt.Println("| 2. Binary Search          |")
				fmt.Println("=============================")
				fmt.Print("Masukkan pilihan (angka): ")
				searchChoiceStr, _ := reader.ReadString('\n')
				searchChoiceStr = strings.TrimSpace(searchChoiceStr)
				searchChoice, err := strconv.Atoi(searchChoiceStr)
				if err != nil || searchChoice < 1 || searchChoice > 2 {
					fmt.Println("Pilihan tidak valid. Kembali ke menu utama.")
				} else {
					fmt.Print("Masukkan kata kunci pencarian: ")
					keyword, _ := reader.ReadString('\n')
					keyword = strings.TrimSpace(keyword)

					switch searchChoice {
					case 1:
						// Sequential Search
						found := sequentialSearch(keyword)
						if !found {
							fmt.Println("Barang dengan Nama, Kategori, atau Stok tersebut tidak ditemukan.")
						}
					case 2:
						// Binary Search
						index := binarySearch(keyword)
						if index != -1 {
							displaySingleBarang(index)
						} else {
							fmt.Println("Barang dengan Nama, Kategori, atau Stok tersebut tidak ditemukan.")
						}
					default:
						fmt.Println("Pilihan tidak valid.")
					}
				}
			case 6:
				clearScreen()
				tampilkanModalDanPendapatan()
			case 7:
				clearScreen()
				tampilkan5BarangTerbanyakTerjual()
			case 8:
				simpanBarangKeFile(barangsFile)
				simpanTransaksiKeFile(transaksisFile)
				fmt.Println("Data disimpan. Keluar dari program.")
				return
			default:
				fmt.Println("Pilihan tidak valid. Silakan coba lagi.")
			}
			fmt.Print("Tekan Enter untuk melanjutkan...")
			bufio.NewReader(os.Stdin).ReadBytes('\n')

		}
	}
}

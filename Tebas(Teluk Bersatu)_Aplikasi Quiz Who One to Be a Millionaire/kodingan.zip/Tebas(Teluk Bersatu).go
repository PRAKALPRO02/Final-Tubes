package main

import (
	"bufio"
	"fmt"
	"math/rand"
	"os"
	"sort"
	"strings"
	"time"
)

type Soal struct {
	ID         int
	Pertanyaan string
	Pilihan    []string
	Jawaban    string
	Benar      int
	Salah      int
}

type Peserta struct {
	Nama string
	Skor int
}

var (
	bankSoal      []Soal
	peserta       []Peserta
	adminUsername = "admin"
	adminPassword = "12345"
)

func loginAdmin() bool {
	fmt.Println("\n=== Login Admin ===")
	var username, password string

	fmt.Print("Masukkan username: ")
	fmt.Scan(&username)
	fmt.Print("Masukkan password: ")
	fmt.Scan(&password)

	if username == adminUsername && password == adminPassword {
		fmt.Println("Login berhasil!")
		return true
	}

	fmt.Println("Login gagal. Username atau password salah.")
	return false
}

func menuAdmin() {
	if !loginAdmin() {
		return
	}

	for {
		fmt.Println("\n=== Menu Admin ===")
		fmt.Println("1. Tambah Soal")
		fmt.Println("2. Ubah Soal")
		fmt.Println("3. Hapus Soal")
		fmt.Println("4. Lihat Statistik Soal")
		fmt.Println("5. Kembali ke Menu Utama")
		fmt.Print("Pilih opsi: ")

		var pilihan int
		fmt.Scan(&pilihan)

		switch pilihan {
		case 1:
			tambahSoal()
		case 2:
			ubahSoal()
		case 3:
			hapusSoal()
		case 4:
			lihatStatistikSoal()
		case 5:
			return
		default:
			fmt.Println("Opsi tidak valid. Silakan coba lagi.")
		}
	}
}

func tambahSoal() {
	var soal Soal
	soal.ID = len(bankSoal) + 1

	reader := bufio.NewReader(os.Stdin)

	fmt.Print("")
	reader.ReadString('\n')

	fmt.Println("Masukkan pertanyaan:")
	soal.Pertanyaan, _ = reader.ReadString('\n')
	soal.Pertanyaan = strings.TrimSpace(soal.Pertanyaan)

	fmt.Println("\nMasukkan 4 pilihan jawaban (pisahkan dengan koma):")
	pilihan, _ := reader.ReadString('\n')
	soal.Pilihan = strings.Split(strings.TrimSpace(pilihan), ",")

	if len(soal.Pilihan) != 4 {
		fmt.Println("\nPilihan jawaban harus berjumlah 4.")
		return
	}

	fmt.Println("\nMasukkan jawaban yang benar (pilih salah satu dari pilihan):")
	soal.Jawaban, _ = reader.ReadString('\n')
	soal.Jawaban = strings.TrimSpace(soal.Jawaban)

	if !contains(soal.Pilihan, soal.Jawaban) {
		fmt.Println("Jawaban harus salah satu dari pilihan yang diberikan.")
		return
	}

	bankSoal = append(bankSoal, soal)
	fmt.Println("Soal berhasil ditambahkan!")
}

func ubahSoal() {
	var id int
	fmt.Print("Masukkan ID soal yang ingin diubah: ")
	fmt.Scan(&id)

	for i, soal := range bankSoal {
		if soal.ID == id {
			reader := bufio.NewReader(os.Stdin)

			fmt.Print("")
			reader.ReadString('\n')

			fmt.Print("Masukkan pertanyaan baru: ")
			bankSoal[i].Pertanyaan, _ = reader.ReadString('\n')
			bankSoal[i].Pertanyaan = strings.TrimSpace(bankSoal[i].Pertanyaan)

			fmt.Println("Masukkan 4 pilihan jawaban baru (pisahkan dengan koma):")
			pilihan, _ := reader.ReadString('\n')
			bankSoal[i].Pilihan = strings.Split(strings.TrimSpace(pilihan), ",")

			if len(bankSoal[i].Pilihan) != 4 {
				fmt.Println("Pilihan jawaban harus berjumlah 4.")
				return
			}

			fmt.Print("Masukkan jawaban yang benar: ")
			fmt.Scan(&bankSoal[i].Jawaban)

			if !contains(bankSoal[i].Pilihan, bankSoal[i].Jawaban) {
				fmt.Println("Jawaban harus salah satu dari pilihan yang diberikan.")
				return
			}

			fmt.Println("Soal berhasil diubah!")
			return
		}
	}

	fmt.Println("Soal tidak ditemukan!")
}

func hapusSoal() {
	var id int
	fmt.Print("Masukkan ID soal yang ingin dihapus: ")
	fmt.Scan(&id)

	for i, soal := range bankSoal {
		if soal.ID == id {
			bankSoal = append(bankSoal[:i], bankSoal[i+1:]...)
			fmt.Println("Soal berhasil dihapus!")
			return
		}
	}

	fmt.Println("Soal tidak ditemukan!")
}

func lihatStatistikSoal() {
	sort.Slice(bankSoal, func(i, j int) bool {
		return bankSoal[i].Benar > bankSoal[j].Benar
	})

	fmt.Print("\n=============================================")
	fmt.Println("\nTop 5 Soal (berdasarkan jawaban benar):")
	fmt.Print("=============================================\n")
	for i, soal := range bankSoal {
		if i >= 5 {
			break
		}
		fmt.Printf("ID: %d | Pertanyaan: %s | Benar: %d | Salah: %d\n",
			soal.ID, soal.Pertanyaan, soal.Benar, soal.Salah)
	}
}

func menuPeserta() {
	fmt.Print("Masukkan nama Anda: ")
	var nama string
	fmt.Scan(&nama)

	found := false
	for _, p := range peserta {
		if p.Nama == nama {
			found = true
			break
		}
	}

	if !found {
		peserta = append(peserta, Peserta{Nama: nama})
	}

	for {
		fmt.Println("\n=== Menu Peserta ===")
		fmt.Println("1. Ikuti Kuis")
		fmt.Println("2. Lihat Papan Skor")
		fmt.Println("3. Kembali ke Menu Utama")
		fmt.Print("Pilih opsi: ")

		var pilihan int
		fmt.Scan(&pilihan)

		switch pilihan {
		case 1:
			ikutiKuis(nama)
		case 2:
			lihatPapanSkor()
		case 3:
			return
		default:
			fmt.Println("Opsi tidak valid. Silakan coba lagi.")
		}
	}
}

func ikutiKuis(nama string) {
	fmt.Print("\nMasukkan jumlah soal yang ingin dijawab: ")
	var n int
	fmt.Scan(&n)

	if n > len(bankSoal) {
		fmt.Println("Jumlah soal di bank soal tidak mencukupi!")
		return
	}

	rand.Seed(time.Now().UnixNano())
	soalTerpilih := rand.Perm(len(bankSoal))[:n]

	skor := 0
	for _, idx := range soalTerpilih {
		soal := bankSoal[idx]
		fmt.Printf("\nPertanyaan: %s\n", soal.Pertanyaan)

		options := []string{"A", "B", "C", "D"}
		for i, pilihan := range soal.Pilihan {
			fmt.Printf("%s. %s\n", options[i], pilihan)
		}

		fmt.Print("Jawaban Anda (masukkan huruf): ")
		var jawaban string
		fmt.Scan(&jawaban)

		jawaban = strings.ToUpper(jawaban)
		jawabanIdx := -1
		for i, option := range options {
			if option == jawaban {
				jawabanIdx = i
				break
			}
		}

		if jawabanIdx >= 0 && jawabanIdx < len(soal.Pilihan) {
			if soal.Pilihan[jawabanIdx] == soal.Jawaban {
				fmt.Println("Benar!")
				skor++
				bankSoal[idx].Benar++
			} else {
				fmt.Println("Salah!")
				bankSoal[idx].Salah++
			}
		} else {
			fmt.Println("Jawaban tidak valid.")
			bankSoal[idx].Salah++
		}
	}

	for i, p := range peserta {
		if p.Nama == nama {
			if skor > p.Skor {
				peserta[i].Skor = skor
			}
			break
		}
	}

	fmt.Printf("Kuis selesai! Skor Anda: %d\n", skor)
}

func lihatPapanSkor() {
	sort.Slice(peserta, func(i, j int) bool {
		return peserta[i].Skor > peserta[j].Skor
	})

	fmt.Println("\n=== Papan Skor ===")
	for i, p := range peserta {
		fmt.Printf("| %d. %s - %d poin |\n", i+1, p.Nama, p.Skor)
	}
}

func contains(slice []string, item string) bool {
	for _, v := range slice {
		if strings.TrimSpace(v) == strings.TrimSpace(item) {
			return true
		}
	}
	return false
}

func main() {
	for {
		fmt.Println("\n=== Menu Utama ===")
		fmt.Println("1. Admin")
		fmt.Println("2. Peserta")
		fmt.Println("3. Keluar")
		fmt.Print("Pilih opsi: ")

		var pilihan int
		fmt.Scan(&pilihan)

		switch pilihan {
		case 1:
			menuAdmin()
		case 2:
			menuPeserta()
		case 3:
			fmt.Println("Terima kasih telah menggunakan program ini!")
			return
		default:
			fmt.Println("Opsi tidak valid. Silakan coba lagi.")
		}
	}
}

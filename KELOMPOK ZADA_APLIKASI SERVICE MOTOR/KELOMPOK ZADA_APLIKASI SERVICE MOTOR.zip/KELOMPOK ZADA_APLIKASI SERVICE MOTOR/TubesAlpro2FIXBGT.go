package main

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

// Struct untuk data
type SparePart struct {
	ID    int
	Nama  string
	Harga float64
	Usage int
}

type Pelanggan struct {
	ID     int
	Nama   string
	Alamat string
}

type Transaksi struct {
	ID          int
	IDPelanggan int
	IDSparePart int
	TotalHarga  float64
	Tanggal     string
}

// Variabel global dengan array statis
var spareParts [100]SparePart
var pelanggan [100]Pelanggan
var transaksi [100]Transaksi
var sparePartCount, pelangganCount, transaksiCount int

func main() {
	var choice int

	// Pilih sumber data
	fmt.Println("Pilih sumber data:")
	fmt.Println("1. Baca data dari file")
	fmt.Println("2. Isi data secara manual")
	fmt.Print("Pilihan: ")
	fmt.Scan(&choice)

	if choice == 1 {
		var filename string
		// Input nama file
		fmt.Print("Masukkan path file (contoh: data/service_motor.txt): ")
		fmt.Scan(&filename)
		checkAndCreateDirectory(filename) // Validasi folder
		loadFromFile(filename)
	} else if choice == 2 {
		fmt.Println("Mulai dengan data kosong. Silakan isi manual.")
	} else {
		fmt.Println("Pilihan tidak valid! Keluar program.")
		return
	}

	// Menu utama
	for {
		fmt.Println("==========================================================")
		fmt.Println("|             		  MENU UTAMA                     |")
		fmt.Println("==========================================================")
		fmt.Println("| 1. Tambah SparePart                         		 |")
		fmt.Println("| 2. Edit SparePart                           		 |")
		fmt.Println("| 3. Hapus SparePart                          		 |")
		fmt.Println("| 4. Tambah Pelanggan                         		 |")
		fmt.Println("| 5. Edit Pelanggan                           		 |")
		fmt.Println("| 6. Hapus Pelanggan                          		 |")
		fmt.Println("| 7. Tambah Transaksi                         		 |")
		fmt.Println("| 8. Edit Transaksi                           		 |")
		fmt.Println("| 9. Hapus Transaksi                          		 |")
		fmt.Println("| 10. Tampilkan Semua Data                    		 |")
		fmt.Println("| 11. Pencarian Pelanggan Berdasarkan Waktu   	 	 |")
		fmt.Println("| 12. Pencarian Pelanggan Berdasarkan SparePart 	 |")
		fmt.Println("| 13. Tampilkan SparePart Terurut Berdasarkan Usage 	 |")
		fmt.Println("| 14. Simpan & Keluar                         		 |")
		fmt.Println("==========================================================")

		var menu int
		fmt.Print("Pilih menu: ")
		fmt.Scan(&menu)

		switch menu {
		case 1:
			addSparePart()
		case 2:
			editSparePart()
		case 3:
			deleteSparePart()
		case 4:
			addPelanggan()
		case 5:
			editPelanggan()
		case 6:
			deletePelanggan()
		case 7:
			addTransaksi()
		case 8:
			editTransaksi()
		case 9:
			deleteTransaksi()
		case 10:
			displayAllData()
		case 11:
			searchByDate()
		case 12:
			searchBySparePart()
		case 13:
			sortSparePartsByUsage()
		}
	}
}

// Fungsi Validasi Folder
func checkAndCreateDirectory(path string) {
	dir := filepath.Dir(path)
	if _, err := os.Stat(dir); os.IsNotExist(err) {
		fmt.Println("Folder tidak ada, membuat folder:", dir)
		os.MkdirAll(dir, os.ModePerm)
	}
}

// Fungsi Membaca Data dari File
func loadFromFile(filename string) {
	file, err := os.Open(filename)
	if err != nil {
		fmt.Println("File tidak ditemukan. Mulai dengan data kosong.")
		return
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		parts := strings.Split(line, "|")

		switch parts[0] {
		case "SPAREPART":
			id, _ := strconv.Atoi(parts[1])
			harga, _ := strconv.ParseFloat(parts[3], 64)
			usage, _ := strconv.Atoi(parts[4])
			spareParts[sparePartCount] = SparePart{id, parts[2], harga, usage}
			sparePartCount++
		case "PELANGGAN":
			id, _ := strconv.Atoi(parts[1])
			pelanggan[pelangganCount] = Pelanggan{id, parts[2], parts[3]}
			pelangganCount++
		case "TRANSAKSI":
			id, _ := strconv.Atoi(parts[1])
			idPelanggan, _ := strconv.Atoi(parts[2])
			idSparePart, _ := strconv.Atoi(parts[3])
			totalHarga, _ := strconv.ParseFloat(parts[4], 64)
			transaksi[transaksiCount] = Transaksi{id, idPelanggan, idSparePart, totalHarga, parts[5]}
			transaksiCount++
		}
	}
	fmt.Println("Data berhasil dimuat dari file:", filename)
}

// Fungsi Tambah SparePart
func addSparePart() {
	var id int
	var nama string
	var harga float64
	var usage int // Tambahkan variabel untuk usage

	fmt.Print("ID SparePart: ")
	fmt.Scan(&id)
	fmt.Print("Nama SparePart: ")
	fmt.Scan(&nama)
	fmt.Print("Harga: ")
	fmt.Scan(&harga)
	fmt.Print("Usage (jumlah penggunaan): ") // Tanyakan jumlah penggunaan
	fmt.Scan(&usage)

	spareParts[sparePartCount] = SparePart{id, nama, harga, usage}
	sparePartCount++
	fmt.Println("SparePart berhasil ditambahkan!")
}

// Fungsi Edit SparePart
func editSparePart() {
	var id int
	fmt.Print("Masukkan ID SparePart yang ingin diedit: ")
	fmt.Scan(&id)

	for i := 0; i < sparePartCount; i++ {
		if spareParts[i].ID == id {
			var nama string
			var harga float64
			fmt.Print("Nama SparePart baru: ")
			fmt.Scan(&nama)
			fmt.Print("Harga baru: ")
			fmt.Scan(&harga)

			spareParts[i].Nama = nama
			spareParts[i].Harga = harga
			fmt.Println("SparePart berhasil diedit!")
			return
		}
	}
	fmt.Println("ID SparePart tidak ditemukan!")
}

// Fungsi Hapus SparePart
func deleteSparePart() {
	var id int
	fmt.Print("Masukkan ID SparePart yang ingin dihapus: ")
	fmt.Scan(&id)

	for i := 0; i < sparePartCount; i++ {
		if spareParts[i].ID == id {
			// Shift remaining elements
			for j := i; j < sparePartCount-1; j++ {
				spareParts[j] = spareParts[j+1]
			}
			sparePartCount--
			fmt.Println("SparePart berhasil dihapus!")
			return
		}
	}
	fmt.Println("ID SparePart tidak ditemukan!")
}

// Fungsi Tambah Pelanggan
func addPelanggan() {
	var id int
	var nama, alamat string

	fmt.Print("ID Pelanggan: ")
	fmt.Scan(&id)
	fmt.Print("Nama: ")
	fmt.Scan(&nama)
	fmt.Print("Alamat: ")
	fmt.Scan(&alamat)

	pelanggan[pelangganCount] = Pelanggan{id, nama, alamat}
	pelangganCount++
	fmt.Println("Pelanggan berhasil ditambahkan!")
}

// Fungsi Edit Pelanggan
func editPelanggan() {
	var id int
	fmt.Print("Masukkan ID Pelanggan yang ingin diedit: ")
	fmt.Scan(&id)

	for i := 0; i < pelangganCount; i++ {
		if pelanggan[i].ID == id {
			var nama, alamat string
			fmt.Print("Nama baru: ")
			fmt.Scan(&nama)
			fmt.Print("Alamat baru: ")
			fmt.Scan(&alamat)

			pelanggan[i].Nama = nama
			pelanggan[i].Alamat = alamat
			fmt.Println("Pelanggan berhasil diedit!")
			return
		}
	}
	fmt.Println("ID Pelanggan tidak ditemukan!")
}

// Fungsi Hapus Pelanggan
func deletePelanggan() {
	var id int
	fmt.Print("Masukkan ID Pelanggan yang ingin dihapus: ")
	fmt.Scan(&id)

	for i := 0; i < pelangganCount; i++ {
		if pelanggan[i].ID == id {
			// Shift remaining elements
			for j := i; j < pelangganCount-1; j++ {
				pelanggan[j] = pelanggan[j+1]
			}
			pelangganCount--
			fmt.Println("Pelanggan berhasil dihapus!")
			return
		}
	}
	fmt.Println("ID Pelanggan tidak ditemukan!")
}

// Fungsi Tambah Transaksi
func addTransaksi() {
	var id, idPelanggan, idSparePart int
	var totalHarga float64
	var tanggal string

	fmt.Print("ID Transaksi: ")
	fmt.Scan(&id)
	fmt.Print("ID Pelanggan: ")
	fmt.Scan(&idPelanggan)
	fmt.Print("ID SparePart: ")
	fmt.Scan(&idSparePart)
	fmt.Print("Total Harga: ")
	fmt.Scan(&totalHarga)
	fmt.Print("Tanggal (YYYY-MM-DD): ")
	fmt.Scan(&tanggal)

	// Menghitung total harga service
	for i := 0; i < sparePartCount; i++ {
		if spareParts[i].ID == idSparePart {
			totalHarga = spareParts[i].Harga * 1.2 // Tarif servis 20%
			spareParts[i].Usage++
			break
		}
	}

	transaksi[transaksiCount] = Transaksi{id, idPelanggan, idSparePart, totalHarga, tanggal}
	transaksiCount++
	fmt.Println("Transaksi berhasil ditambahkan!")
}

// Fungsi Edit Transaksi
func editTransaksi() {
	var id int
	fmt.Print("Masukkan ID Transaksi yang ingin diedit: ")
	fmt.Scan(&id)

	for i := 0; i < transaksiCount; i++ {
		if transaksi[i].ID == id {
			var idPelanggan, idSparePart int
			var totalHarga float64
			var tanggal string

			fmt.Print("ID Pelanggan baru: ")
			fmt.Scan(&idPelanggan)
			fmt.Print("ID SparePart baru: ")
			fmt.Scan(&idSparePart)
			fmt.Print("Total Harga baru: ")
			fmt.Scan(&totalHarga)
			fmt.Print("Tanggal baru (YYYY-MM-DD): ")
			fmt.Scan(&tanggal)

			transaksi[i].IDPelanggan = idPelanggan
			transaksi[i].IDSparePart = idSparePart
			transaksi[i].TotalHarga = totalHarga
			transaksi[i].Tanggal = tanggal
			fmt.Println("Transaksi berhasil diedit!")
			return
		}
	}
	fmt.Println("ID Transaksi tidak ditemukan!")
}

// Fungsi Hapus Transaksi
func deleteTransaksi() {
	var id int
	fmt.Print("Masukkan ID Transaksi yang ingin dihapus: ")
	fmt.Scan(&id)

	for i := 0; i < transaksiCount; i++ {
		if transaksi[i].ID == id {
			// Shift remaining elements
			for j := i; j < transaksiCount-1; j++ {
				transaksi[j] = transaksi[j+1]
			}
			transaksiCount--
			fmt.Println("Transaksi berhasil dihapus!")
			return
		}
	}
	fmt.Println("ID Transaksi tidak ditemukan!")
}

// Fungsi Menampilkan Semua Data
func displayAllData() {
	fmt.Println("\nSpareParts:")
	for i := 0; i < sparePartCount; i++ {
		fmt.Printf("ID: %d, Nama: %s, Harga: %.2f, Usage: %d\n", spareParts[i].ID, spareParts[i].Nama, spareParts[i].Harga, spareParts[i].Usage)
	}

	fmt.Println("\nPelanggan:")
	for i := 0; i < pelangganCount; i++ {
		fmt.Printf("ID: %d, Nama: %s, Alamat: %s\n", pelanggan[i].ID, pelanggan[i].Nama, pelanggan[i].Alamat)
	}

	fmt.Println("\nTransaksi:")
	for i := 0; i < transaksiCount; i++ {
		fmt.Printf("ID: %d, ID Pelanggan: %d, ID SparePart: %d, Total Harga: %.2f, Tanggal: %s\n", transaksi[i].ID, transaksi[i].IDPelanggan, transaksi[i].IDSparePart, transaksi[i].TotalHarga, transaksi[i].Tanggal)
	}
}

// Fungsi Pencarian Berdasarkan Tanggal
func searchByDate() {
	var startDate, endDate string
	fmt.Print("Masukkan tanggal awal (YYYY-MM-DD): ")
	fmt.Scan(&startDate)
	fmt.Print("Masukkan tanggal akhir (YYYY-MM-DD): ")
	fmt.Scan(&endDate)

	fmt.Println("Pelanggan yang melakukan service antara", startDate, "dan", endDate)
	for i := 0; i < transaksiCount; i++ {
		if transaksi[i].Tanggal >= startDate && transaksi[i].Tanggal <= endDate {
			for j := 0; j < pelangganCount; j++ {
				if pelanggan[j].ID == transaksi[i].IDPelanggan {
					fmt.Printf("Pelanggan: %s, Tanggal: %s\n", pelanggan[j].Nama, transaksi[i].Tanggal)
				}
			}
		}
	}
}

// Fungsi Pencarian Berdasarkan SparePart
func searchBySparePart() {
	var sparePartID int
	fmt.Print("Masukkan ID SparePart yang dicari: ")
	fmt.Scan(&sparePartID)

	fmt.Println("Pelanggan yang membeli SparePart ID", sparePartID)
	for i := 0; i < transaksiCount; i++ {
		if transaksi[i].IDSparePart == sparePartID {
			for j := 0; j < pelangganCount; j++ {
				if pelanggan[j].ID == transaksi[i].IDPelanggan {
					fmt.Printf("Pelanggan: %s, Tanggal: %s\n", pelanggan[j].Nama, transaksi[i].Tanggal)
				}
			}
		}
	}
}

// Fungsi Menampilkan SparePart Terurut Berdasarkan Penggunaan
func sortSparePartsByUsage() {
	fmt.Println("SpareParts terurut berdasarkan jumlah penggunaan:")
	// Sorting spareparts menggunakan bubble sort berdasarkan usage
	for i := 0; i < sparePartCount-1; i++ {
		for j := 0; j < sparePartCount-i-1; j++ {
			if spareParts[j].Usage < spareParts[j+1].Usage {
				spareParts[j], spareParts[j+1] = spareParts[j+1], spareParts[j]
			}
		}
	}
	displayAllData()
}

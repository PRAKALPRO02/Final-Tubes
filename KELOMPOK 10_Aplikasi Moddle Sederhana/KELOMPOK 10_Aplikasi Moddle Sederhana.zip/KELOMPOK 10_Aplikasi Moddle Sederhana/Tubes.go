package main

import (
	"bufio"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
)

type Soal struct {
	Pertanyaan string
	Pilihan    []string // Opsi jawaban
	Jawaban    string   // Jawaban yang benar
	Nilai      int
}

type Forum struct {
	Topik  string
	Pesan  []string
	Siswa  []string // Menyimpan nama siswa yang mengirim pesan
}


type Tugas struct {
	Pertanyaan   string
	JawabanSiswa map[string]string // Jawaban tiap siswa
	NilaiSiswa   map[string]int    // Nilai tiap siswa
}

type Siswa struct {
	Nama  string
	Nilai int
}

var soalKuis []Soal
var forumDiskusi []Forum
var siswa []Siswa
var tugas []Tugas

var guruCredentials = map[string]string{
	"guru1": "123",
	
}

func main() {
	reader := bufio.NewReader(os.Stdin)

	for {
		fmt.Println("\n====== Menu: ======")
		fmt.Println("1. Guru")
		fmt.Println("2. Siswa")
		fmt.Println("3. Keluar")
		fmt.Print("Pilih peran: ")

		pilihan, _ := reader.ReadString('\n')
		pilihan = strings.TrimSpace(pilihan)

		switch pilihan {
		case "1":
			if loginGuru(reader) {
				menuGuru(reader)
			}
		case "2":
			menuSiswa(reader)
		case "3":
			fmt.Println("Keluar dari program.")
			return
		default:
			fmt.Println("Pilihan tidak valid.")
		}
	}
}

func loginGuru(reader *bufio.Reader) bool {
	fmt.Print("Masukkan username: ")
	username, _ := reader.ReadString('\n')
	username = strings.TrimSpace(username)

	fmt.Print("Masukkan password: ")
	password, _ := reader.ReadString('\n')
	password = strings.TrimSpace(password)

	if pass, exists := guruCredentials[username]; exists && pass == password {
		fmt.Println("Login berhasil. Selamat datang,", username)
		return true
	} else {
		fmt.Println("Login gagal. Username atau password salah.")
		return false
	}
}

func menuGuru(reader *bufio.Reader) {
	for {
		fmt.Println("+==================================================+")
		fmt.Println("|         	Menu Guru                          |")
		fmt.Println("+==================================================+")
		fmt.Println("|	1. Tambah Soal Kuis                        |")
		fmt.Println("|	2. Ubah Soal Kuis                          |")
		fmt.Println("|	3. Hapus Soal Kuis                         |")
		fmt.Println("|	4. Tambah Forum Diskusi                    |")
		fmt.Println("|	5. Ubah Forum Diskusi                      |")
		fmt.Println("|	6. Hapus Forum Diskusi                     |")
		fmt.Println("|	7. Tambah Tugas                            |")
		fmt.Println("|	8. Ubah Tugas                              |")
		fmt.Println("|	9. Hapus Tugas                             |")
		fmt.Println("|	10. Tampilkan Nilai Siswa (Kuis)           |")
		fmt.Println("|	11. Tampilkan Nilai Siswa (Tugas)          |")
		fmt.Println("|	12. Lihat Data Terurut Berdasarkan Nilai   |")
		fmt.Println("|	13. Kembali                                |")
		fmt.Println("|	14. Tampilkan menu forum                   |")
		fmt.Println("+==================================================+")
		fmt.Print("Pilih menu: ")

		pilihan, _ := reader.ReadString('\n')
		pilihan = strings.TrimSpace(pilihan)

		switch pilihan {
		case "1":
			tambahSoal(reader)
		case "2":
			ubahSoal(reader)
		case "3":
			hapusSoal(reader)
		case "4":
			tambahForum(reader)
		case "5":
			ubahForum(reader)
		case "6":
			hapusForum(reader)
		case "7":
			tambahTugas(reader)
		case "8":
			ubahTugas(reader)
		case "9":
			hapusTugas(reader)
		case "10":
			tampilkanNilaiKuis()
		case "11":
			tampilkanNilaiTugas()
		case "12":
			lihatDataTerurut()
		case "13":
			return
		case "14":
			tampilkanForumPesan()
		default:
			fmt.Println("Pilihan tidak valid.")
		}
	}
}

func tampilkanForumPesan() {
	if len(forumDiskusi) == 0 {
		fmt.Println("Belum ada forum diskusi.")
		return
	}

	fmt.Println("\nDaftar Forum Diskusi:")
	for i, f := range forumDiskusi {
		fmt.Printf("%d. %s\n", i+1, f.Topik)
		fmt.Println("Pesan-pesan:")
		for j, pesan := range f.Pesan {
			fmt.Printf("  %d. %s\n", j+1, pesan)
			fmt.Printf("Pengirim: %s\n", f.Siswa[j])
		}
	}
}


func lihatDataTerurut() {
	fmt.Println("\nData Terurut Berdasarkan Nilai :")

	if len(siswa) == 0 {
		fmt.Println("Belum ada data siswa.")
		return
	}

	// Kuis
	fmt.Println("\n=-=-= Kuis :=-=-=")
	if len(soalKuis) > 0 {
		sortedSiswa := make([]Siswa, len(siswa))
		copy(sortedSiswa, siswa)
		sort.Slice(sortedSiswa, func(i, j int) bool {
			return sortedSiswa[i].Nilai > sortedSiswa[j].Nilai
		})
		for _, s := range sortedSiswa {
			fmt.Printf("%s: %d\n", s.Nama, s.Nilai)
		}
		fmt.Printf("Jumlah peserta kuis: %d\n", len(siswa))
	} else {
		fmt.Println("Belum ada soal kuis.")
	}

	// Tugas
	fmt.Println("\nTugas:")
	if len(tugas) > 0 {
		for i, t := range tugas {
			fmt.Printf("Tugas %d: %s\n", i+1, t.Pertanyaan)
			participants := []struct {
				Nama  string
				Nilai int
			}{}
			for nama, nilai := range t.NilaiSiswa {
				participants = append(participants, struct {
					Nama  string
					Nilai int
				}{Nama: nama, Nilai: nilai})
			}
			sort.Slice(participants, func(i, j int) bool {
				return participants[i].Nilai > participants[j].Nilai
			})
			for _, p := range participants {
				fmt.Printf("%s: %d\n", p.Nama, p.Nilai)
			}
			fmt.Printf("Jumlah peserta tugas: %d\n", len(participants))
		}
	} else {
		fmt.Println("Belum ada tugas.")
	}
}


func menuSiswa(reader *bufio.Reader) {
	fmt.Print("Masukkan nama Anda: ")
	nama, _ := reader.ReadString('\n')
	nama = strings.TrimSpace(nama)

	siswa = append(siswa, Siswa{Nama: nama, Nilai: 0})
	indexSiswa := len(siswa) - 1

	for {
		fmt.Println("\nMenu Siswa:")
		fmt.Println("1. Ikut Kuis")
		fmt.Println("2. Forum Diskusi")
		fmt.Println("3. Kerjakan Tugas")
		fmt.Println("4. Kembali")
		fmt.Print("Pilih menu: ")

		pilihan, _ := reader.ReadString('\n')
		pilihan = strings.TrimSpace(pilihan)

		switch pilihan {
		case "1":
			ikutiKuis(reader, &siswa[indexSiswa])
		case "2":
			ikutiForum(reader)
		case "3":
			kerjakanTugas(reader, nama)
		case "4":
			return
		default:
			fmt.Println("Pilihan tidak valid.")
		}
	}
}

func tambahSoal(reader *bufio.Reader) {
	var s Soal
	fmt.Print("Masukkan pertanyaan: ")
	s.Pertanyaan, _ = reader.ReadString('\n')
	s.Pertanyaan = strings.TrimSpace(s.Pertanyaan)

	fmt.Print("Masukkan jumlah opsi jawaban: ")
	jumlahOpsiStr, _ := reader.ReadString('\n')
	jumlahOpsiStr = strings.TrimSpace(jumlahOpsiStr)
	jumlahOpsi, _ := strconv.Atoi(jumlahOpsiStr)

	for i := 0; i < jumlahOpsi; i++ {
		fmt.Printf("Masukkan opsi jawaban %d: ", i+1)
		opsi, _ := reader.ReadString('\n')
		opsi = strings.TrimSpace(opsi)
		s.Pilihan = append(s.Pilihan, opsi)
	}

	fmt.Print("Masukkan jawaban yang benar (huruf): ")
	s.Jawaban, _ = reader.ReadString('\n')
	s.Jawaban = strings.TrimSpace(s.Jawaban)

	fmt.Print("Masukkan nilai: ")
	nilaiStr, _ := reader.ReadString('\n')
	nilaiStr = strings.TrimSpace(nilaiStr)
	s.Nilai, _ = strconv.Atoi(nilaiStr)

	soalKuis = append(soalKuis, s)
	fmt.Println("Soal berhasil ditambahkan.")
}

func ubahSoal(reader *bufio.Reader) {
	if len(soalKuis) == 0 {
		fmt.Println("Belum ada soal.")
		return
	}

	tampilkanSoal()
	fmt.Print("Pilih nomor soal yang ingin diubah: ")
	nomorStr, _ := reader.ReadString('\n')
	nomorStr = strings.TrimSpace(nomorStr)
	nomor, _ := strconv.Atoi(nomorStr)

	if nomor < 1 || nomor > len(soalKuis) {
		fmt.Println("Nomor soal tidak valid.")
		return
	}

	nomor--
	fmt.Printf("Soal lama: %s\n", soalKuis[nomor].Pertanyaan)
	fmt.Print("Masukkan soal baru: ")
	soalKuis[nomor].Pertanyaan, _ = reader.ReadString('\n')
	soalKuis[nomor].Pertanyaan = strings.TrimSpace(soalKuis[nomor].Pertanyaan)
	fmt.Print("Masukkan jawaban baru: ")
	soalKuis[nomor].Jawaban, _ = reader.ReadString('\n')
	soalKuis[nomor].Jawaban = strings.TrimSpace(soalKuis[nomor].Jawaban)
	fmt.Print("Masukkan nilai baru: ")
	nilaiStr, _ := reader.ReadString('\n')
	nilaiStr = strings.TrimSpace(nilaiStr)
	soalKuis[nomor].Nilai, _ = strconv.Atoi(nilaiStr)

	fmt.Println("Soal berhasil diubah.")
}

func hapusSoal(reader *bufio.Reader) {
	if len(soalKuis) == 0 {
		fmt.Println("Belum ada soal.")
		return
	}

	tampilkanSoal()
	fmt.Print("Pilih nomor soal yang ingin dihapus: ")
	nomorStr, _ := reader.ReadString('\n')
	nomorStr = strings.TrimSpace(nomorStr)
	nomor, _ := strconv.Atoi(nomorStr)

	if nomor < 1 || nomor > len(soalKuis) {
		fmt.Println("Nomor soal tidak valid.")
		return
	}

	nomor--
	soalKuis = append(soalKuis[:nomor], soalKuis[nomor+1:]...)
	fmt.Println("Soal berhasil dihapus.")
}

func tampilkanSoal() {
	fmt.Println("\nDaftar Soal Kuis:")
	for i, s := range soalKuis {
		fmt.Printf("%d. %s (Nilai: %d)\n", i+1, s.Pertanyaan, s.Nilai)
	}
}

func tambahForum(reader *bufio.Reader) {
	var f Forum
	fmt.Print("Masukkan topik forum: ")
	f.Topik, _ = reader.ReadString('\n')
	f.Topik = strings.TrimSpace(f.Topik)
	f.Pesan = make([]string, 0) // Inisialisasi slice Pesan
	forumDiskusi = append(forumDiskusi, f)
	fmt.Println("Forum berhasil ditambahkan.")
}

func ubahForum(reader *bufio.Reader) {
	if len(forumDiskusi) == 0 {
		fmt.Println("Belum ada forum.")
		return
	}

	fmt.Println("\nDaftar Forum:")
	for i, f := range forumDiskusi {
		fmt.Printf("%d. %s\n", i+1, f.Topik)
	}

	fmt.Print("Pilih nomor forum yang ingin diubah: ")
	nomorStr, _ := reader.ReadString('\n')
	nomorStr = strings.TrimSpace(nomorStr)
	nomor, _ := strconv.Atoi(nomorStr)

	if nomor < 1 || nomor > len(forumDiskusi) {
		fmt.Println("Nomor forum tidak valid.")
		return
	}

	nomor--
	fmt.Printf("Topik lama: %s\n", forumDiskusi[nomor].Topik)
	fmt.Print("Masukkan topik baru: ")
	topikBaru, _ := reader.ReadString('\n')
	forumDiskusi[nomor].Topik = strings.TrimSpace(topikBaru)
	fmt.Println("Forum berhasil diubah.")
}

func hapusForum(reader *bufio.Reader) {
	if len(forumDiskusi) == 0 {
		fmt.Println("Belum ada forum.")
		return
	}

	fmt.Println("\nDaftar Forum:")
	for i, f := range forumDiskusi {
		fmt.Printf("%d. %s\n", i+1, f.Topik)
	}

	fmt.Print("Pilih nomor forum yang ingin dihapus: ")
	nomorStr, _ := reader.ReadString('\n')
	nomorStr = strings.TrimSpace(nomorStr)
	nomor, _ := strconv.Atoi(nomorStr)

	if nomor < 1 || nomor > len(forumDiskusi) {
		fmt.Println("Nomor forum tidak valid.")
		return
	}

	nomor--
	forumDiskusi = append(forumDiskusi[:nomor], forumDiskusi[nomor+1:]...)
	fmt.Println("Forum berhasil dihapus.")
}

func tambahTugas(reader *bufio.Reader) {
	var t Tugas
	fmt.Print("Masukkan pertanyaan tugas: ")
	t.Pertanyaan, _ = reader.ReadString('\n')
	t.Pertanyaan = strings.TrimSpace(t.Pertanyaan)

	// Menambahkan jawaban yang benar
	fmt.Print("Masukkan jawaban yang benar: ")
	jawabanBenar, _ := reader.ReadString('\n')
	t.JawabanSiswa = make(map[string]string)
	t.JawabanSiswa[""] = strings.TrimSpace(jawabanBenar) // Menggunakan key kosong agar mudah diakses

	// Menyiapkan map nilai siswa
	t.NilaiSiswa = make(map[string]int)

	tugas = append(tugas, t)
	fmt.Println("Tugas berhasil ditambahkan.")
}


func ubahTugas(reader *bufio.Reader) {
	if len(tugas) == 0 {
		fmt.Println("Belum ada tugas.")
		return
	}

	fmt.Println("\nDaftar Tugas:")
	for i, t := range tugas {
		fmt.Printf("%d. %s\n", i+1, t.Pertanyaan)
	}

	fmt.Print("Pilih nomor tugas yang ingin diubah: ")
	nomorStr, _ := reader.ReadString('\n')
	nomorStr = strings.TrimSpace(nomorStr)
	nomor, _ := strconv.Atoi(nomorStr)

	if nomor < 1 || nomor > len(tugas) {
		fmt.Println("Nomor tugas tidak valid.")
		return
	}

	nomor--
	fmt.Printf("Tugas lama: %s\n", tugas[nomor].Pertanyaan)
	fmt.Print("Masukkan pertanyaan tugas baru: ")
	pertanyaanBaru, _ := reader.ReadString('\n')
	tugas[nomor].Pertanyaan = strings.TrimSpace(pertanyaanBaru)
	fmt.Println("Tugas berhasil diubah.")
}

func hapusTugas(reader *bufio.Reader) {
	if len(tugas) == 0 {
		fmt.Println("Belum ada tugas.")
		return
	}

	fmt.Println("\nDaftar Tugas:")
	for i, t := range tugas {
		fmt.Printf("%d. %s\n", i+1, t.Pertanyaan)
	}

	fmt.Print("Pilih nomor tugas yang ingin dihapus: ")
	nomorStr, _ := reader.ReadString('\n')
	nomorStr = strings.TrimSpace(nomorStr)
	nomor, _ := strconv.Atoi(nomorStr)

	if nomor < 1 || nomor > len(tugas) {
		fmt.Println("Nomor tugas tidak valid.")
		return
	}

	nomor--
	tugas = append(tugas[:nomor], tugas[nomor+1:]...)
	fmt.Println("Tugas berhasil dihapus.")
}

func nilaiTugas(reader *bufio.Reader) {
	if len(tugas) == 0 {
		fmt.Println("Belum ada tugas.")
		return
	}

	fmt.Println("\nDaftar Tugas:")
	for i, t := range tugas {
		fmt.Printf("%d. %s\n", i+1, t.Pertanyaan)
	}

	fmt.Print("Pilih nomor tugas yang ingin dinilai: ")
	nomorStr, _ := reader.ReadString('\n')
	nomorStr = strings.TrimSpace(nomorStr)
	nomor, _ := strconv.Atoi(nomorStr)

	if nomor < 1 || nomor > len(tugas) {
		fmt.Println("Nomor tugas tidak valid.")
		return
	}

	nomor--
	fmt.Print("Masukkan nama siswa yang ingin dinilai: ")
	namaSiswa, _ := reader.ReadString('\n')
	namaSiswa = strings.TrimSpace(namaSiswa)

	if !siswaAda(namaSiswa) {
		fmt.Println("Siswa tidak ditemukan.")
		return
	}

	fmt.Print("Masukkan nilai tugas: ")
	nilaiStr, _ := reader.ReadString('\n')
	nilaiStr = strings.TrimSpace(nilaiStr)
	nilai, _ := strconv.Atoi(nilaiStr)

	tugas[nomor].NilaiSiswa[namaSiswa] = nilai
	fmt.Println("Nilai berhasil dimasukkan.")
}

func siswaAda(nama string) bool {
	for _, s := range siswa {
		if s.Nama == nama {
			return true
		}
	}
	return false
}

func tampilkanNilaiKuis() {
	fmt.Println("\nDaftar Nilai Kuis:")
	for _, s := range siswa {
		fmt.Printf("%s: %d\n", s.Nama, s.Nilai)
	}
}

func tampilkanNilaiTugas() {
    file, err := os.OpenFile("nilai_tugas.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
    if err != nil {
        fmt.Println("Error membuka file:", err)
        return
    }
    defer file.Close()

    fmt.Println("\nDaftar Nilai Tugas:")
    for _, t := range tugas {
        for nama, nilai := range t.NilaiSiswa {
            fmt.Printf("%s: %d\n", nama, nilai)
            _, err := fmt.Fprintf(file, "%s: %d\n", nama, nilai)
            if err != nil {
                fmt.Println("Error menulis ke file:", err)
            }
        }
    }
}

func ikutiKuis(reader *bufio.Reader, siswa *Siswa) {
	if len(soalKuis) == 0 {
			fmt.Println("Belum ada soal kuis.")
			return
	}

	nilaiTotal := 0
	for _, soal := range soalKuis {
			fmt.Println(soal.Pertanyaan)
			for i, opsi := range soal.Pilihan {
					fmt.Printf("%c. %s\n", 'A'+i, opsi)
			}

			fmt.Print("Pilih jawaban (A, B, C, ...): ")
			jawabanSiswa, _ := reader.ReadString('\n')
			jawabanSiswa = strings.ToUpper(strings.TrimSpace(jawabanSiswa))

			if jawabanSiswa == soal.Jawaban {
					nilaiTotal += soal.Nilai
			}
	}

	siswa.Nilai = nilaiTotal
	fmt.Printf("%s, nilai Anda adalah: %d\n", siswa.Nama, nilaiTotal)
}

func ikutiForum(reader *bufio.Reader) {
    if len(forumDiskusi) == 0 {
        fmt.Println("Belum ada forum diskusi.")
        return
    }

    fmt.Println("\nDaftar Forum Diskusi:")
    for i, f := range forumDiskusi {
        fmt.Printf("%d. %s\n", i+1, f.Topik)
    }

    fmt.Print("Pilih forum untuk berpartisipasi: ")
    nomorStr, _ := reader.ReadString('\n')
    nomorStr = strings.TrimSpace(nomorStr)
    nomor, _ := strconv.Atoi(nomorStr)

    if nomor < 1 || nomor > len(forumDiskusi) {
        fmt.Println("Nomor forum tidak valid.")
        return
    }

    nomor--

    fmt.Print("Masukkan nama Anda: ")
    namaSiswa, _ := reader.ReadString('\n')
    namaSiswa = strings.TrimSpace(namaSiswa)

    // Mencari indeks siswa yang sesuai dengan nama
    var indexSiswa int
    found := false
    for i, s := range siswa {
        if s.Nama == namaSiswa {
            indexSiswa = i
            found = true
            break
        }
    }

    if !found {
        fmt.Println("Siswa tidak ditemukan.")
        return
    }

    fmt.Print("Masukkan pesan untuk forum: ")
    pesan, _ := reader.ReadString('\n')

    // Menambahkan pesan dan nama siswa
    forumDiskusi[nomor].Pesan = append(forumDiskusi[nomor].Pesan, pesan)
    forumDiskusi[nomor].Siswa = append(forumDiskusi[nomor].Siswa, siswa[indexSiswa].Nama)
    fmt.Println("Pesan berhasil ditambahkan.")
}



func kerjakanTugas(reader *bufio.Reader, nama string) {
	if len(tugas) == 0 {
		fmt.Println("Belum ada tugas.")
		return
	}

	fmt.Println("\nDaftar Tugas:")
	for i, t := range tugas {
		fmt.Printf("%d. %s\n", i+1, t.Pertanyaan)
	}

	fmt.Print("Pilih nomor tugas yang ingin dikerjakan: ")
	nomorStr, _ := reader.ReadString('\n')
	nomorStr = strings.TrimSpace(nomorStr)
	nomor, _ := strconv.Atoi(nomorStr)

	if nomor < 1 || nomor > len(tugas) {
		fmt.Println("Nomor tugas tidak valid.")
		return
	}

	nomor--

	// Menampilkan pertanyaan dan meminta jawaban
	fmt.Println(tugas[nomor].Pertanyaan)
	fmt.Print("Masukkan jawaban untuk tugas: ")
	jawaban, _ := reader.ReadString('\n')
	jawaban = strings.TrimSpace(jawaban)

	// Menilai jawaban siswa
	if jawaban == tugas[nomor].JawabanSiswa[""] { // Bandingkan dengan jawaban yang benar
		tugas[nomor].NilaiSiswa[nama] = 100 // Berikan nilai penuh jika benar
	} else {
		tugas[nomor].NilaiSiswa[nama] = 0 // Berikan nilai 0 jika salah
	}

	fmt.Println("Jawaban tugas berhasil disubmit.")
}

